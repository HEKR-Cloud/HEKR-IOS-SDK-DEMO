/**
 * Created by wangguojun on 15/10/7.
 */
window.onload = function(){
    var headlefthekr = document.getElementById("head-left-hekrh");
    var headlefthekrm = document.getElementById("head-left-hekrm");
    var headlefthekrn = document.getElementById("head-left-hekrn");
    var homeviewright = document.getElementById("home-view-right");
    var homeviewhekr = document.getElementById("home-view-hekr");
    var homeviewleft = document.getElementById("home-view-left");

    var can = document.getElementById("can");
    var ctx = can.getContext("2d");

    ctx.translate(50,50);  // 移动坐标原点至（50,50）
    ctx.rotate(-90*Math.PI/180);  // 转动角度起点至-90
    var i = 0;
    var r = 44;
    ctx.lineCap = 'square';
    //白条
    ctx.strokeStyle = '#fff';
    ctx.beginPath();
    ctx.lineWidth = '10';
    ctx.arc(0, 0, r, 0, 2*Math.PI,true);
    ctx.stroke();
    //描边
    ctx.strokeStyle = '#e57148';
    ctx.beginPath();
    ctx.lineWidth = '1';
    ctx.arc(0, 0, r+5.5, 0, 2*Math.PI,true);
    ctx.stroke();

    setInterval(function() {
        //一帧
        ctx.beginPath();
        ctx.lineWidth = '10';
        ctx.arc(0, 0, r, 0, -10*Math.PI/180,true);
        ctx.stroke();
        ctx.rotate(-10*Math.PI/180);
        i++;
        if (i === 36) {
            i = 0;
            ctx.clearRect(-50,-50,100,100);
            //白条
            ctx.strokeStyle = '#fff';
            ctx.beginPath();
            ctx.lineWidth = '10';
            ctx.arc(0, 0, r, 0, 2*Math.PI,true);
            ctx.stroke();
            //描边
            ctx.strokeStyle = '#e57148';
            ctx.beginPath();
            ctx.lineWidth = '1';
            ctx.arc(0, 0, r+5.5, 0, 2*Math.PI,true);
            ctx.stroke();
        }
    },150000000);

    //侧边菜单栏
    headlefthekr.onclick = function(){
        homeviewhekr.style.marginLeft = "-15%";
    };
    headlefthekrm.onclick = function(){
        homeviewhekr.style.marginLeft = "-100%";
    };
    headlefthekrn.onclick = function(){
        homeviewhekr.style.marginLeft = "-100%";
    };
    homeviewleft.onclick = function(){
        homeviewhekr.style.marginLeft = "-100%";
    };
};
