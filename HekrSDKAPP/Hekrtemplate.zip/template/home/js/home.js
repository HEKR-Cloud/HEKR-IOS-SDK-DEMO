/**
 * Created by wangguojun on 15/10/9.
 */
window.onload = function(){

    //首页动态效果
    var homebodyhekr = document.getElementById("home-body-hekr");
    var editorheadhekr = document.getElementById("editor-head-hekr");
    var homefoothekr = document.getElementById("home-foot-hekr");
    var homefootnone = document.getElementById("home-foot-none");

    var headcenterhekr = document.getElementById("head-center-hekr");
    var headcenterdown = document.getElementById("head-center-down");
    var homeheadup = document.getElementById("home-head-up");
    var homefootbackground = document.getElementById("home-foot-background");
    var homenonebackground = document.getElementById("home-none-background");

    var headlefthekr = document.getElementById("head-left-hekrh");
    var headlefthekrm = document.getElementById("head-left-hekrm");
    var headlefthekrn = document.getElementById("head-left-hekrn");
    var homeviewright = document.getElementById("home-view-right");
    var homeviewhekr = document.getElementById("home-view-hekr");

    var homeviewleft = document.getElementById("home-view-left");
    var homeasidefirst = document.getElementById("home-aside-first");
    var homeasidesecond = document.getElementById("home-aside-second");
    var homeasidethird = document.getElementById("home-aside-third");
    var homeasidefour = document.getElementById("home-aside-four");

    var homeasideone = document.getElementById("home-aside-one");
    var homeasidetwo = document.getElementById("home-aside-two");
    var homeasidethree = document.getElementById("home-aside-three");
    var homeasidefive = document.getElementById("home-aside-five");
    var homeasidesix = document.getElementById("home-aside-six");

    var homelittleword = document.getElementById("home-little-word");
    var homesulationopen = document.getElementById("home-sulation-open");
    var homesulationclose = document.getElementById("home-sulation-close");
    var homelittleopen = document.getElementById("home-little-open");
    var homelittleclose = document.getElementById("home-little-close");

    var can = document.getElementById("can");
    var ctx = can.getContext("2d");

    ctx.translate(50,50);  // 移动坐标原点至（50,50）
    ctx.rotate(-90*Math.PI/180);  // 转动角度起点至-90
    var i = 0;
    var r = 44;
    ctx.lineCap = 'square';
    //白条
    ctx.strokeStyle = '#fff';
    ctx.beginPath();
    ctx.lineWidth = '10';
    ctx.arc(0, 0, r, 0, 2*Math.PI,true);
    ctx.stroke();
    //描边
    ctx.strokeStyle = '#e57148';
    ctx.beginPath();
    ctx.lineWidth = '1';
    ctx.arc(0, 0, r+5.5, 0, 2*Math.PI,true);
    ctx.stroke();

    setInterval(function() {
        //一帧
        ctx.beginPath();
        ctx.lineWidth = '10';
        ctx.arc(0, 0, r, 0, -10*Math.PI/180,true);
        ctx.stroke();
        ctx.rotate(-10*Math.PI/180);
        i++;
        if (i === 36) {
            i = 0;
            ctx.clearRect(-50,-50,100,100);
            //白条
            ctx.strokeStyle = '#fff';
            ctx.beginPath();
            ctx.lineWidth = '10';
            ctx.arc(0, 0, r, 0, 2*Math.PI,true);
            ctx.stroke();
            //描边
            ctx.strokeStyle = '#e57148';
            ctx.beginPath();
            ctx.lineWidth = '1';
            ctx.arc(0, 0, r+5.5, 0, 2*Math.PI,true);
            ctx.stroke();
        }
    },180);

    //首页伸缩动效
    homebodyhekr.onclick = function(){
        homebodyhekr.style.display = "none";
        homefoothekr.style.display = "none";
        editorheadhekr.style.display = "block";
        homefootnone.style.display = "block";
    };

    editorheadhekr.onclick = function(){
        editorheadhekr.style.display = "none";
        homefootnone.style.display = "none";
        homebodyhekr.style.display = "block";
        homefoothekr.style.display = "block";
    };

    //我的设备下拉框
    headcenterhekr.onclick = function(){
        headcenterdown.style.display = "block";
        homefootbackground.style.display = "block";
        homenonebackground.style.display = "block";
    };
    homefoothekr.onclick = function(){
        headcenterdown.style.display = "none";
        homefootbackground.style.display = "none";
        homenonebackground.style.display = "none";
    };
    homefootnone.onclick = function(){
        headcenterdown.style.display = "none";
        homefootbackground.style.display = "none";
        homenonebackground.style.display = "none";
    };

    //侧边菜单栏
    headlefthekr.onclick = function(){
        homeviewhekr.style.marginLeft = "-15%";
    };
    headlefthekrm.onclick = function(){
        homeviewhekr.style.marginLeft = "-100%";
    };
    homeviewleft.onclick = function(){
        homeviewhekr.style.marginLeft = "-100%";
    };
    homeasidefirst.onclick = function(){
        homeviewhekr.style.marginLeft = "-100%";
    };
    homeasidesecond.onclick = function(){
        homeviewhekr.style.marginLeft = "-100%";
    };
    homeasidethird.onclick = function(){
        homeviewhekr.style.marginLeft = "-100%";
    };
    homeasidefour.onclick = function(){
        homeviewhekr.style.marginLeft = "-100%";
    };
    homeasideone.onclick = function(){
        homeviewhekr.style.marginLeft = "-100%";
    };
    homeasidetwo.onclick = function(){
        homeviewhekr.style.marginLeft = "-100%";
    };
    homeasidethree.onclick = function(){
        homeviewhekr.style.marginLeft = "-100%";
    };
    homeasidefive.onclick = function(){
        homeviewhekr.style.marginLeft = "-100%";
    };
    homeasidesix.onclick = function(){
        homeviewhekr.style.marginLeft = "-100%";
    };

    //设备开关
    homelittleword.onclick = function(){
        if(homesulationopen.style.display == "block"){
            homesulationopen.style.display = "none";
            homelittleopen.style.display = "none";
            homelittleclose.style.display = "block";
            homesulationclose.style.display = "block";
        }else{
            homelittleclose.style.display = "none";
            homesulationclose.style.display = "none";
            homesulationopen.style.display = "block";
            homelittleopen.style.display = "block";
        }
    };
};
